# (c) 2025 SalesAutoMate. All Rights Reserved.

import tkinter as tk
from tkinter import messagebox, filedialog
from datetime import datetime
import hashlib

def generate_license():
    system = entry_system.get().strip()
    node = entry_node.get().strip()
    txn_id = entry_txn.get().strip()
    tag = var_tag.get()

    if not system or not node or not txn_id:
        messagebox.showerror("Error", "Please fill all fields.")
        return

    salt = "SalesAutoMate™_Secure_v2.0"
    date_str = datetime.now().strftime("%Y-%m-%d")
    raw_key = f"{system}{node}{salt}"
    digest = hashlib.sha256(raw_key.encode()).hexdigest().upper()
    blocks = [digest[i:i+5] for i in range(0, 25, 5)]
    formatted_key = "-".join(blocks)
    verify_string = f"{formatted_key}|{date_str}|{txn_id}|{salt}"
    key_hash = hashlib.sha256(verify_string.encode()).hexdigest()

    content = f"{formatted_key}\n{date_str}\nTXN:{txn_id}\nHASH:{key_hash}\n"

    path = filedialog.asksaveasfilename(defaultextension=".key", filetypes=[("License File", "*.key")])
    if path:
        with open(path, "w") as f:
            f.write(content)
        messagebox.showinfo("Success", "license.key file generated successfully!")

app = tk.Tk()
app.title("License Generator - SalesAutoMate™")

tk.Label(app, text="System (e.g., Windows):").grid(row=0, column=0, sticky='e')
tk.Label(app, text="Node/Machine Name:").grid(row=1, column=0, sticky='e')
tk.Label(app, text="Transaction ID:").grid(row=2, column=0, sticky='e')

entry_system = tk.Entry(app, width=30)
entry_node = tk.Entry(app, width=30)
entry_txn = tk.Entry(app, width=30)

entry_system.grid(row=0, column=1, padx=5, pady=5)
entry_node.grid(row=1, column=1, padx=5, pady=5)
entry_txn.grid(row=2, column=1, padx=5, pady=5)

var_tag = tk.StringVar(value="Trial")
tk.Label(app, text="License Type:").grid(row=3, column=0, sticky='e')
tk.OptionMenu(app, var_tag, "Trial", "Paid").grid(row=3, column=1, sticky='w', padx=5)

tk.Button(app, text="Generate license.key", command=generate_license, bg="#4CAF50", fg="white").grid(row=4, column=0, columnspan=2, pady=10)

app.mainloop()
