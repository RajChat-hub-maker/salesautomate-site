from fpdf import FPDF

class PDF(FPDF):
    def header(self):
        self.set_font("SalesAutoMate", size=60)
        self.cell(0, 80, "\uE903", ln=True, align='C')  # Renders your logo

    def footer(self):
        self.set_y(-40)
        self.set_font("DejaVu", "", 12)
        self.multi_cell(0, 10,
            "© 2025 SalesAutoMate™\nA proprietary brand by Rajdeep Chatterjee.\nAll rights reserved. ™",
            align="C"
        )

# Create PDF
pdf = PDF()

# Register fonts (uni=True = Unicode support)
pdf.add_font("SalesAutoMate", "", "SalesAutoMate_fixed.ttf", uni=True)
pdf.add_font("DejaVu", "", "DejaVuSans.ttf", uni=True)

pdf.add_page()
pdf.output("SalesAutoMate_Brand_Logo.pdf")