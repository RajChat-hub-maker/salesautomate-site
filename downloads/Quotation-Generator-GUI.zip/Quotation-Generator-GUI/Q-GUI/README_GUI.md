# 🖥️ SalesAutoMate™ v2.0 GUI — Quotation Automation System (Desktop Edition)

> **© 2025 SalesAutoMate™ – An automation system by Rajdeep Chatterjee. All rights reserved.**

---

## 📄 Overview

**SalesAutoMate™ GUI** is the desktop-based graphical version of the CLI-based quotation generator, offering a visually intuitive, user-friendly interface for creating professional business quotations with embedded license control and branding support.

Designed with speed, usability, and presentation in mind, this version is tailored for sales teams and office staff who prefer GUI applications over command-line interfaces.

---

## 🛠️ Key Features

- ✅ **Modern GUI interface** built using Python’s `tkinter`
- ✅ **Easy input** of customer details and product entries via form
- ✅ **Dynamic product table with unit, quantity, rate, and auto amount**
- ✅ **Auto-generated Quote ID with fiscal formatting**
- ✅ **One-click PDF generation** with custom branding
- ✅ **Brand logo strip and contact info included in PDF**
- ✅ **Professional header layout with red line styling**
- ✅ **Trial license system with expiry enforcement**
- ✅ **License reactivation panel with transaction ID**
- ✅ **Unicode font support for footer gear icon ⚙**
- ✅ **No internet required — fully offline desktop tool**

---

## 📂 Directory Structure

```
quotation_gui/
├── gui.py                  # Main GUI application
├── license.key             # Auto-generated trial or reactivated key
├── LICENSE.pdf             # License agreement PDF
├── assets/
│   ├── fonts/
│   │   └── DejaVuSans.ttf  # Unicode font
│   └── logos/              # Brand logos (bosch.png, kpt.png, etc.)
├── output/                 # Generated PDF quotations
└── README.md               # This file
```

---

## 🧾 Sample Output PDF

- ✅ SHREE KRISHNA HARDWARE styled header
- ✅ Red double lines below business name
- ✅ Quote ID: `ABC/HHMMSS/YY-YY`
- ✅ Dynamic product table with clean layout
- ✅ Terms & Conditions
- ✅ Office contact & signature block
- ✅ Authorized Brands with logos
- ✅ Footer with ⚙ SalesAutoMate™ branding

---

## 🚀 How to Use (Step-by-Step)

1. **Launch the GUI**:
   ```bash
   python gui.py
   ```

2. **On First Run**:
   - You'll be shown the LICENSE AGREEMENT (PDF).
   - Type `agree` to continue.
   - A trial license key will be generated (valid for 1 year).

3. **Enter quotation details**:
   - Company name
   - Contact/location
   - Credit period
   - Add item entries one by one:
     - Item name
     - Quantity
     - Unit (pcs, kg, lit, etc.)
     - Rate

4. **Click `Generate PDF`** — your quotation is saved in:
   ```
   /output/ABC_<quote-no>.pdf
   ```

---

## 🔐 Licensing System

- ✅ **Trial Period**: 365 days
- ✅ **After Expiry**: Reactivation panel will prompt for:
  - New paid license key (in Windows-style format)
  - Transaction ID for verification
- ✅ **Stored securely** in `license.key` with SHA-256 hash

**Example Format**:
```
SMLK9-ZXG43-WPQ29-VT123-YU776
2025-06-15
TXN:TXN958211234
HASH:6d8a23f29cbdacf67a...
```

---

## 📌 Requirements

- Python 3.7+
- Required libraries:

```bash
pip install reportlab
```

(You may also need: `pillow`, `tkinter` – which is pre-installed in most Python distributions)

---

## 📦 Features Planned for Next Versions

- PDF preview before save
- Export to Excel/CSV
- Email quotation directly from app
- Quotation editing history

---

## ⚠️ Legal Notice

- `SalesAutoMate™` is a registered trademark of **Rajdeep Chatterjee**
- Unauthorized use, distribution, or modification of this software is strictly prohibited
- All PDFs contain © 2025 ⚙ SalesAutoMate™. All rights reserved.

---

## ✉️ Contact

**Rajdeep Chatterjee**  
📧 rc9163253@gmail.com  
📍 Durgapur, West Bengal, India

---

## 🔒 Confidentiality Notice

This software is **proprietary and confidential**. Distribution outside of a license agreement will result in legal action.