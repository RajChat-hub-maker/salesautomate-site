# gui.py
# © 2025 SalesAutoMate™. All rights reserved.
# Licensed under EULA.
# GUI Version of Quotation Generator

import os
import sys
import platform
import hashlib
from datetime import datetime, timedelta
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

LICENSE_KEY_FILE = "license.key"
OUTPUT_DIR = "output"
LOGO_DIR = "assets/logos"
STATIC_SALT = "SalesAutoMate™_Secure_v2.0"
TRIAL_DAYS = 365

pdfmetrics.registerFont(TTFont("DejaVuSans", "assets/fonts/DejaVuSans.ttf"))

# --- License ---
def generate_license_key():
    sys_info = platform.system() + platform.node()     
    raw = sys_info + STATIC_SALT
    digest = hashlib.sha256(raw.encode()).hexdigest().upper()
    blocks = [digest[i:i+5] for i in range(0, 25, 5)]
    return "-".join(blocks)

def verify_license():
    expected_key = generate_license_key()
    if os.path.exists(LICENSE_KEY_FILE):
        with open(LICENSE_KEY_FILE) as f:
            lines = f.read().splitlines()
            if len(lines) >= 4:
                license_key, start_date, txn_id, hash_line = lines[0], lines[1], lines[2][4:], lines[3][5:]
                verify = f"{license_key}|{start_date}|{txn_id}|{STATIC_SALT}"
                if hashlib.sha256(verify.encode()).hexdigest() == hash_line:
                    dt = datetime.strptime(start_date, "%Y-%m-%d")
                    if (dt + timedelta(days=TRIAL_DAYS)) >= datetime.now():
                        return True
                    else:
                        messagebox.showinfo("License", "Trial expired. Reactivation required.")
    return False

def reactivate_license():
    new_key = simpledialog.askstring("Reactivation", "Enter your new license key:").strip().upper()
    if not (len(new_key) == 29 and new_key.count("-") == 4):
        messagebox.showerror("Invalid", "Invalid license key format.")
        return
    txn_id = simpledialog.askstring("Reactivation", "Enter transaction ID:").strip()
    if not txn_id or len(txn_id) < 6:
        messagebox.showerror("Invalid", "Invalid transaction ID.")
        return
    today = datetime.now().strftime("%Y-%m-%d")
    verify = f"{new_key}|{today}|{txn_id}|{STATIC_SALT}"
    key_hash = hashlib.sha256(verify.encode()).hexdigest()
    with open(LICENSE_KEY_FILE, "w") as f:
        f.write(f"{new_key}\n{today}\nTXN:{txn_id}\nHASH:{key_hash}\n")
    messagebox.showinfo("Success", "License reactivated successfully.")

# --- PDF ---
def draw_table(c, headers, items, x, y_start):
    row_height = 18
    col_widths = [40, 220, 70, 70, 80]
    y = y_start
    c.setFillColor(colors.lightgrey)
    c.setStrokeColor(colors.black)  # ✅ Ensures border is black   
    c.rect(x, y, sum(col_widths), row_height, fill=True, stroke=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 10)
    for i, header in enumerate(headers):
        c.drawString(x + sum(col_widths[:i]) + 2, y + 4, header)
    y -= row_height
    c.setFont("Helvetica", 10)
    for idx, item in enumerate(items, 1):
        row = [
            str(idx),
            item["Item"],
            f"{item['Qty']} {item['Unit']}",
            f"{float(item['Rate']):.2f}",
            f"{float(item['Amount']):.2f}"
        ]
        for i, cell in enumerate(row):
            c.drawString(x + sum(col_widths[:i]) + 2, y + 4, cell)

        c.setStrokeColor(colors.black)         
        c.rect(x, y, sum(col_widths), row_height, stroke=True)
        y -= row_height
    return y

def generate_pdf(data):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    filename = os.path.join(OUTPUT_DIR, f"ABC_{data['QuoteNo']}.pdf")                 
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4
    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(colors.darkred)
    c.drawString(50, height - 40, "ABC ENTITY")
    c.setStrokeColor(colors.darkred)
    c.setLineWidth(1)
    c.line(50, height - 47, width - 50, height - 47)
    c.setLineWidth(0.5)
    c.line(50, height - 50, width - 50, height - 50)
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.black)
    c.drawString(50, height - 65, "ANY ADDRESS, ANY PLACE – 74   |   6464647842")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 110, data['Company'])
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 130, data['Customer'])
    c.drawRightString(width - 50, height - 110, f"DATE: {datetime.now():%d.%m.%Y}")
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 160, f"Our Quotation No – {data['QuoteID']}")
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 185, "Reference: OVER MAIL")
    c.drawString(50, height - 200, "Dear Sir,")
    c.drawString(50, height - 215, "Thank you very much for the courtesy extended to the undersigned.")
    c.drawString(50, height - 230, "We are pleased to submit below our offer for the following item:")
    y = draw_table(c, ["Sl No.", "Item", "Quantity", "Rate/Price", "Amount"], data['Items'], 50, height - 260)
    y -= 10
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(540, y, f"Total: ₹{data['Total']:.2f}")
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "Terms & Condition")
    c.setFont("Helvetica", 10)
    for line in [
        "TAX: GST WILL BE ADDED EXTRA AS APPLICABLE.",
        f"PAYMENT TERMS: PO AGAINST WITHIN {data['Credit']} DAYS AS PER MSME.",
        "DELIVERY: 5 TO 7 DAYS",
        "ALL THE MATERIALS DELIVERY WILL BE SUBJECT TO AVAILABILITY FROM OEM’S END.",
        "Please find our offer in line with your requirements and your valued order will reach us at the earliest."
    ]:
        y -= 15
        c.drawString(50, y, line)
    y -= 30
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "Office:")
    c.setFont("Helvetica", 10)
    for line in [
        "ANY ADDRESS, ANY ROAD, ANY PLACE – 12",
        "Mobile: 9238383022 / 6363746488",
        "Email: any@gmail.com"
    ]:
        y -= 15
        c.drawString(105, y, line)
    y -= 30
    c.drawString(50, y, "Thanks & Regards")
    y -= 15
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "ABC ENTITY")
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(width / 2, y, "AUTHORIZED SALE & SERVICE:")
    y -= 40
    logos = ["bosch", "dewalt", "eibenstock", "kpt", "dongcheng", "hitachi", "ralliwolf", "fag", "groz", "polymak"]
    size = (70, 30)
    spacing = 20
    x_start = (width - ((size[0] + spacing) * 5 - spacing)) / 2
    for i, row in enumerate([logos[:5], logos[5:]]):
        for j, name in enumerate(row):
            path = os.path.join(LOGO_DIR, f"{name}.png")
            x = x_start + j * (size[0] + spacing)
            if os.path.exists(path):
                c.drawImage(ImageReader(path), x, y - (i * 35), width=size[0], height=size[1], mask='auto')
            else:
                c.setFillColor(colors.red)
                c.drawString(x, y - (i * 35), f"[{name.upper()}]")
    c.setFont("DejaVuSans", 8)
    c.setFillColor(colors.grey)
    c.drawCentredString(width / 2, 20, "© 2025 ⚙ SalesAutoMate™. All rights reserved.")
    c.save()
    return filename

# --- GUI ---
class QuotationApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SalesAutoMate GUI Quotation Generator")
        self.geometry("700x600")
        self.items = []
        self.setup_ui()

    def setup_ui(self):
        frm = tk.Frame(self)
        frm.pack(pady=10)

        tk.Label(frm, text="Company:").grid(row=0, column=0)
        self.company = tk.Entry(frm, width=40)
        self.company.grid(row=0, column=1)

        tk.Label(frm, text="Contact Person:").grid(row=1, column=0)
        self.customer = tk.Entry(frm, width=40)
        self.customer.grid(row=1, column=1)

        tk.Label(frm, text="Credit Days:").grid(row=2, column=0)
        self.credit = tk.Entry(frm, width=10)
        self.credit.grid(row=2, column=1)

        self.tree = ttk.Treeview(self, columns=("Item", "Qty", "Unit", "Rate"), show='headings')
        for col in self.tree["columns"]:
            self.tree.heading(col, text=col)
            self.tree.column(col, width=100)
        self.tree.pack(pady=10)

        add_btn = tk.Button(self, text="Add Item", command=self.add_item)
        add_btn.pack()

        gen_btn = tk.Button(self, text="Generate PDF", command=self.generate_quote)
        gen_btn.pack(pady=5)

    def add_item(self):
        item = simpledialog.askstring("Item", "Enter item name:")
        qty = simpledialog.askstring("Qty", "Enter quantity:")
        unit = simpledialog.askstring("Unit", "Enter unit (kg, pcs, etc):")
        rate = simpledialog.askfloat("Rate", "Enter rate:")
        try:
            amount = float(qty) * float(rate)
            self.items.append({"Item": item, "Qty": qty, "Unit": unit, "Rate": rate, "Amount": amount})
            self.tree.insert('', 'end', values=(item, qty, unit, rate))
        except:
            messagebox.showerror("Error", "Invalid item details")

    def get_quote_id(self):                                    
        now = datetime.now()
        fiscal = f"{now.year % 100}-{(now.year + 1) % 100}"
        number = now.strftime("%H%M%S")
        return f"ABC/{number}/{fiscal}", number                                       

    def generate_quote(self):
        if not verify_license():
            if messagebox.askyesno("Trial Expired", "Reactivate license now?"):
                reactivate_license()
                return
            else:
                return
        total = sum(i['Amount'] for i in self.items)
        quote_id, quote_no = self.get_quote_id()                      
        data = {
            "Company": self.company.get(),
            "Customer": self.customer.get(),
            "Credit": self.credit.get(),
            "Items": self.items,
            "Total": total,
            "QuoteID": quote_id,
            "QuoteNo": quote_no
        }
        filename = generate_pdf(data)
        messagebox.showinfo("Done", f"Quotation saved to: {filename}")

if __name__ == "__main__":
    app = QuotationApp()
    app.mainloop()
