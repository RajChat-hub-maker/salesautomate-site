from setuptools import setup, find_packages

setup(
    name="json-indexing-engine",
    version="1.3.2",
    author="Rajdeep Chatterjee",
    author_email="contact@salesautomate.com",  # You can change or remove this
    description="A SalesAutoMate™ JSON indexing and search engine",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/json-indexing-engine",  # Update or remove if not on GitHub
    packages=find_packages(exclude=["examples", "tests"]),
    include_package_data=True,
    install_requires=[
        # Minimal standard library usage — no external dependencies
    ],
    entry_points={
        'console_scripts': [
            'json-indexer=jsindx.cli:main',  # You’ll need to wrap `cli.py` in a `main()` function
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: Other/Proprietary License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)