#Placeholder for future GUI or API integration
# Could use Flask or Tkinter depending on target users
print("[INFO] app.py: GUI/API app coming soon...")
