#--- README.md ---
# SalesAutoMate™ JSON Indexing Engine

An advanced engine to index, search, and retrieve complex JSON datasets, optimized for use in SalesAutoMate™ automation tools.

## Features
- JSON file loading (single and nested records)
- Dynamic indexing
- Search (exact, partial, date range, numeric)
- CLI and GUI-ready
- Easy integration

## Usage
```bash
python cli.py --file examples/sample_data.json --fields invoice_id client.name --search client.name --value "Alpha Corp"
```

## Future
- REST API support
- Desktop GUI (Tkinter/Electron)
- Export to CSV/PDF
