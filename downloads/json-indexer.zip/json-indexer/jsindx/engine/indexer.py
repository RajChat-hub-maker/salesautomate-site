from jsindx.engine.utils import get_nested_value

class JSONIndexer:
    def __init__(self, json_data, index_fields):
        self.data = json_data
        self.index_fields = index_fields
        self.index = {}

    def create_index(self):
        for record in self.data:
            for field in self.index_fields:
                value = get_nested_value(record, field)
                if value is not None:
                    self.index.setdefault(field, {}).setdefault(value, []).append(record)

    def get_index(self):
        return self.index
