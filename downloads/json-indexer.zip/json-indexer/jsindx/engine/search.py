from jsindx.engine.utils import get_nested_value
import re
from datetime import datetime

class JSONSearch:
    def __init__(self, indexer):
        self.indexer = indexer
        self.data = indexer.data

    def exact_match(self, field, value):
        return self.indexer.index.get(field, {}).get(value, [])

    def partial_match(self, field, substring):
        results = []
        for record in self.data:
            value = get_nested_value(record, field)
            if isinstance(value, str) and substring.lower() in value.lower():
                results.append(record)
        return results

    def date_range(self, field, start_date, end_date):
        results = []
        for record in self.data:
            value = get_nested_value(record, field)
            try:
                date_val = datetime.fromisoformat(value)
                if start_date <= date_val <= end_date:
                    results.append(record)
            except:
                continue
        return results

    def numeric_condition(self, field, operator, target):
        results = []
        for record in self.data:
            value = get_nested_value(record, field)
            try:
                if operator == '<' and value < target:
                    results.append(record)
                elif operator == '>' and value > target:
                    results.append(record)
                elif operator == '=' and value == target:
                    results.append(record)
            except:
                continue
        return results
