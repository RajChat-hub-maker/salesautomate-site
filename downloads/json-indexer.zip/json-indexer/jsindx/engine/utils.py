def get_nested_value(data, field):
    keys = field.split('.')
    for key in keys:
        if isinstance(data, dict):
            data = data.get(key, None)
        else:
            return None
    return data