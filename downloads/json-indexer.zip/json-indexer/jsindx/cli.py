import argparse
import json
import csv
from datetime import datetime
from rich import print
from jsindx.engine.loader import load_json
from jsindx.engine.indexer import JSONIndexer
from jsindx.engine.search import JSONSearch

PAGE_SIZE = 5

def main():
    parser = argparse.ArgumentParser(description="SalesAutoMate JSON Indexing Engine")
    parser.add_argument("--file", required=True, help="Path to JSON file")
    parser.add_argument("--fields", nargs='+', required=True, help="Fields to index")
    parser.add_argument("--search", help="Search field")
    parser.add_argument("--value", help="Value to search")
    parser.add_argument("--partial", action='store_true', help="Partial match mode")
    parser.add_argument("--date-range", nargs=2, metavar=('START', 'END'), help="Filter by date range (ISO format)")
    parser.add_argument("--numeric", nargs=3, metavar=('FIELD', 'OPERATOR', 'TARGET'), help="Filter by numeric condition")
    parser.add_argument("--export", help="Export results to JSON or CSV file")
    args = parser.parse_args()

    json_data = load_json(args.file)
    indexer = JSONIndexer(json_data, args.fields)
    indexer.create_index()
    search = JSONSearch(indexer)

    results = []

    # Search logic
    if args.search and args.value:
        print(f"[cyan]🔍 Searching for:[/cyan] [bold]{args.value}[/bold] in [green]{args.search}[/green]")
        if args.partial:
            results = search.partial_match(args.search, args.value)
        else:
            results = search.exact_match(args.search, args.value)
    elif args.date_range:
        start = datetime.fromisoformat(args.date_range[0])
        end = datetime.fromisoformat(args.date_range[1])
        results = search.date_range(args.search, start, end)
        print(f"[cyan]📅 Filtering by date range:[/cyan] {start} to {end}")
    elif args.numeric:
        field, op, target = args.numeric
        try:
            target = float(target)
            results = search.numeric_condition(field, op, target)
            print(f"[cyan]🔢 Numeric condition:[/cyan] {field} {op} {target}")
        except ValueError:
            print("[red]❌ Invalid numeric target.[/red]")
            return
    else:
        print("[yellow]ℹ️ No search performed. Use --search and --value, --date-range, or --numeric to filter.[/yellow]")

    if results:
        print(f"[green]✅ {len(results)} result(s) found:[/green]")
        page = 0
        while True:
            start_index = page * PAGE_SIZE
            end_index = start_index + PAGE_SIZE
            for r in results[start_index:end_index]:
                print(json.dumps(r, indent=2, ensure_ascii=False))
            if end_index >= len(results):
                break
            user_input = input("[blue]\n🔽 Show more? (y/n): [/blue]").strip().lower()
            if user_input != 'y':
                break
            page += 1

        # Summary stats
        print("\n[bold cyan]📊 Summary:[/bold cyan]")
        print(f"[green]Total Results:[/green] {len(results)}")
        print(f"[green]Fields Indexed:[/green] {', '.join(args.fields)}")

    else:
        print("[yellow]⚠️ No results found.[/yellow]")

    # Optional export
    if args.export and results:
        if args.export.endswith(".json"):
            with open(args.export, "w", encoding="utf-8") as f:
                json.dump(results, f, indent=2, ensure_ascii=False)
            print(f"[blue]📤 Exported to JSON:[/blue] {args.export}")
        elif args.export.endswith(".csv"):
            with open(args.export, "w", newline='', encoding="utf-8") as f:
                writer = csv.writer(f)
                headers = sorted({key for record in results for key in record.keys()})
                writer.writerow(headers)
                for record in results:
                    writer.writerow([record.get(h, "") for h in headers])
            print(f"[blue]📤 Exported to CSV:[/blue] {args.export}")
        else:
            print("[red]❌ Unsupported export format. Use .json or .csv[/red]")

if __name__ == "__main__":
    main()

