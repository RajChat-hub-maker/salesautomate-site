# 📧 Email Finder Tool

A lightweight, fast, and mobile-friendly web application that finds publicly available professional email addresses associated with any domain — powered by the [Hunter.io](https://hunter.io) API.

> 🔒 Developed by [SalesAutoMate™](https://salesautomate.site) | © 2025 SalesAutoMate. All rights reserved.

---

## 🚀 Live Demo

You can run it locally or deploy to any static hosting provider. A sample screenshot is shown below:

![Screenshot](./screenshot.png)

---

## ✨ Features

- ✅ Search for email addresses associated with any domain
- ⚡ Fast, real-time API response via Hunter.io
- 📱 Responsive, mobile-optimized UI
- 💡 Clean and minimalist design
- 🔒 No backend dependencies (Variant 2)
- 🧪 Supports easy local development using PHP server
- 📦 Modular code using `index.html`, `style.css`, and `script.js`
- 🏷️ Professional footer watermark in Adobe-style

---

## 📁 Project Structure

```plaintext
email-finder/
├── index.html        # Main UI layout
├── style.css         # Stylesheet for UI
├── script.js         # Handles API calls
├── hunter.php        # Placeholder for future backend (not used)
└── README.md         # Project documentation

---

🛠️ Installation & Local Development

> Prerequisite: Install PHP or Python (Termux, Ubuntu, macOS, Windows WSL, etc.)



📦 PHP (Recommended for Local CORS Support)

php -S 127.0.0.1:8080

Then open:
➡️ http://127.0.0.1:8080 in your browser

🐍 Python (Static Server – not suitable for direct API use)

python -m http.server 8000

⚠️ Note: You may face CORS issues using Hunter API directly via python http.server.


---

🔐 How It Works

The app uses the Hunter.io Domain Search API to fetch email addresses related to a specific domain.

🔗 API Request (from script.js)

https://api.hunter.io/v2/domain-search?domain=example.com&api_key=YOUR_HUNTER_API_KEY

📄 Example Response

{
  "data": {
    "domain": "example.com",
    "emails": [
      {
        "value": "john@example.com",
        "type": "personal"
      },
      {
        "value": "contact@example.com",
        "type": "generic"
      }
    ]
  }
}


---

🧠 Usage Guide

1. Open the tool in browser (e.g. http://localhost:8080)


2. Enter a domain (e.g. openai.com)


3. Click Find Emails


4. Wait for results to be fetched and displayed




---

🌐 Hosting & Deployment

You can deploy this tool to:

Netlify

Vercel

GitHub Pages

Firebase Hosting



---

📦 Future Enhancements

[ ] Add name-based email generation (Hunter’s Email Finder API)

[ ] Export found emails to CSV

[ ] Copy-to-clipboard feature

[ ] Email categorization (Personal / Generic icons)

[ ] Proxy support for API hiding

[ ] Backend version (Node.js / PHP)



---

💼 Branding

🧠 Product by: SalesAutoMate™

👨‍💻 Developer: Rajdeep Chatterjee

📜 License: Proprietary

📅 Year: 2025

🌐 Website: https://salesautomate.site



---

💬 Contact

If you have suggestions or collaboration ideas, feel free to contact:

📧 Email: support@salesautomate.site |info@salesautomate.site |rajdeepchatterjee@salesautomate.site |rc9163253@gmail.com 
🌐 Website: https://salesautomate.site


---

🛡️ Legal

This product is for educational and research purposes only.
You are solely responsible for complying with local laws and Hunter.io's terms of service.

> © 2025 SalesAutoMate™. All rights reserved.



---