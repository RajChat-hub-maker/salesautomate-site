<?php
header('Content-Type: application/json');

// Replace with your actual Hunter.io API key
$apiKey = '97daf7f4933eaad46aaf5df4a41e680411c787ab';

if (!isset($_GET['domain'])) {
    echo json_encode(['error' => 'Domain is required']);
    exit;
}

$domain = urlencode($_GET['domain']);
$hunterUrl = "https://api.hunter.io/v2/domain-search?domain=$domain&api_key=$apiKey";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $hunterUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$response = curl_exec($ch);

if (curl_errno($ch)) {
    echo json_encode(['error' => curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);
echo $response;

