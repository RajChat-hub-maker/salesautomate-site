const apiKey = "97daf7f4933eaad46aaf5df4a41e680411c787ab"; // Replace this

document.getElementById("searchBtn").addEventListener("click", async () => {
  const domain = document.getElementById("domain").value.trim();
  const results = document.getElementById("results");
  results.innerHTML = "Searching...";

  if (!domain) {
    results.innerHTML = "Please enter a domain.";
    return;
  }

  try {
    const res = await fetch(
      `https://api.hunter.io/v2/domain-search?domain=${encodeURIComponent(domain)}&api_key=${apiKey}`
    );
    const data = await res.json();

    if (data && data.data && data.data.emails && data.data.emails.length > 0) {
      const emails = data.data.emails;
      results.innerHTML = "<strong>Emails found:</strong><ul>" +
        emails.map(e => `<li>${e.value}</li>`).join("") +
        "</ul>";
    } else {
      results.innerHTML = "No emails found.";
    }
  } catch (err) {
    results.innerHTML = "Failed to fetch results. Check your API key or network.";
  }
});