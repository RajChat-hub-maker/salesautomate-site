# === backend/routes/inventory.py ===
from flask import Blueprint, request, render_template, redirect, session
from backend.db import get_db_connection

inventory_bp = Blueprint('inventory', __name__)

@inventory_bp.route('/')
def dashboard():
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM inventory').fetchall()
    conn.close()
    return render_template('index.html', items=items)

@inventory_bp.route('/add-item', methods=['POST'])
def add_item():
    name = request.form['name']
    qty = int(request.form['quantity'])
    batch = request.form['batch']
    expiry = request.form['expiry']
    conn = get_db_connection()
    conn.execute('INSERT INTO inventory (name, quantity, batch, expiry) VALUES (?, ?, ?, ?)',
                 (name, qty, batch, expiry))
    conn.commit()
    conn.close()
    return redirect('/')

@inventory_bp.route('/update-stock/<int:item_id>/<action>', methods=['POST'])
def update_stock(item_id, action):
    conn = get_db_connection()
    item = conn.execute('SELECT * FROM inventory WHERE id = ?', (item_id,)).fetchone()
    if not item:
        conn.close()
        return "Item not found", 404

    quantity = item['quantity']
    if action == "add":
        quantity += 1
    elif action == "remove" and quantity > 0:
        quantity -= 1

    conn.execute('UPDATE inventory SET quantity = ? WHERE id = ?', (quantity, item_id))
    conn.commit()
    conn.close()
    return redirect('/')
