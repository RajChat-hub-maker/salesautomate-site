// Frontend JS logic
# === frontend/js/app.js ===
console.log("StockMate™ JS Loaded");

# === frontend/css/style.css ===
body {
    font-family: Arial, sans-serif;
    margin: 20px;
}
