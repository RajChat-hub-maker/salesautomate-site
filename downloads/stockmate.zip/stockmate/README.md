# StockMate
Inventory Management System powered by SalesAutoMate™.


# StockMate v1.0
_A Product of SalesAutoMate™ by Rajdeep Chatterjee_

StockMate is a powerful, subscription-based inventory management system designed for small to mid-sized businesses. Built using Python (Flask + SQLite), it allows users to efficiently track stock levels, manage purchases and sales, and view live inventory—all through a responsive, browser-based interface.

---

## 🚀 Features

### 📦 Inventory Control
- Add/Edit/Delete stock items
- Batch number & expiry tracking
- Quantity tracking with increase/decrease buttons

### 📥 Purchases & 📤 Sales
- Add incoming stock via item form
- Adjust stock on sales with one-click buttons

### 📊 Dashboard
- View all items in a styled, mobile-friendly table
- See total item count instantly
- Actions available per item (➕ Add / ➖ Remove stock)

### 🔐 Authentication
- Secure login system
- Logout functionality
- Admin-only access

### 🧑‍💼 Admin Panel (built-in)
- Quick Add Item
- Inventory overview
- Real-time data update

### 🧾 Reporting & Future Modules
- Export to PDF/CSV (upcoming)
- Low-stock alerts (upcoming)

---

## 📱 Responsive UI

StockMate’s dashboard is designed to look and feel like a native Google Sheet on Android. Built-in responsiveness ensures it's easy to use on desktops, tablets, and mobile phones.

---

## 🛠️ Tech Stack

| Layer       | Technology            |
|-------------|------------------------|
| Frontend    | HTML, CSS, JS (inline) |
| Backend     | Python (Flask)         |
| Database    | SQLite                 |
| License     | Proprietary (EULA-based under SalesAutoMate™) |

---

## 🔧 Installation

```bash
# Clone or download the project
cd StockMate

# Install required packages
pip install -r requirements.txt

# Initialize the database
python backend/utils/init_db.py

# Start the Flask server
python -m backend.app
```

Visit [http://127.0.0.1:5000](http://127.0.0.1:5000) in your browser.

---

## 🔑 Default Login

| Username | Password |
|----------|----------|
| admin    | admin123 |

---

## 📂 Project Structure

```
StockMate/
│
├── backend/
│   ├── app.py              # Main Flask app
│   ├── db.py               # DB connection
│   ├── routes/             # Flask routes (auth, inventory)
│   ├── models/             # Python classes (Item, User)
│   └── utils/init_db.py    # DB setup script
│
├── templates/              # Jinja2 HTML templates
│   ├── login.html
│   └── index.html
│
├── static/                 # Optional for uploads
├── data/                   # SQLite database file
├── LICENSE.txt             # Proprietary license
├── README.md               # You are here
└── requirements.txt        # Python dependencies
```

---

## 📜 License

This software is licensed under a **proprietary license** governed by the SalesAutoMate™ brand. Redistribution, modification, or resale without permission is strictly prohibited.

© 2025 Rajdeep Chatterjee. All rights reserved.

---

## 📧 Contact-rc9163253@gmail.com 

For subscriptions, support, or licensing:
📩 rajdeepchatterjee.dev [at] email.com

