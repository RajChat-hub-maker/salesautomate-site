
# 📦 SalesAutoMate™ v2.0 – A Quotation Automation System

> **© 2025 SalesAutoMate™ – An automation system by Rajdeep Chatterjee. All rights reserved.**

---

## 📄 Overview

**SalesAutoMate™** is a proprietary, command-line driven sales quotation generation system specifically designed for small to mid-size businesses that need **fast, professional, and legally formatted sales quotes** — with special customization for clients like **Shree Krishna Hardware**.

This version (v2.0) focuses on speed, accuracy, branding consistency, and legally bound protection of business assets, with seamless CLI workflow and no dependency on GUI or online services.

---

## 🛠️ Key Features

- ✅ **Generate legally styled sales quotes** with professional branding
- ✅ **Dynamic product selection** from an inventory (godown) file
- ✅ **Automatic quote ID generation** based on fiscal time
- ✅ **Prints quote to PDF** using `reportlab` with full layout styling
- ✅ **Custom corporate branding** (Header + Company Details + Footer)
- ✅ **Styled authorized brands section** with unique color-blocks per brand
- ✅ **Office address block** styled with consistency and professional layout
- ✅ **Copyright footer** per EULA

---

## 📂 Directory Structure

```
sales_automate_2.0/
├── cli.py              # Main CLI application
├── godown.csv          # Product inventory (editable)
├── output/             # Folder to store generated PDF quotes
└── README.md           # This file
```

---

## 🧾 Sample Output

Your generated quote will look like:

- Business header (e.g., "SHREE KRISHNA HARDWARE")
- Quote ID with fiscal date code
- Table of selected products (Sl No, Item, Qty, Rate, Amount)
- Terms & Conditions
- Footer with “Thanks & Regards”, contact info, and office address
- Colored brand logo blocks (Bosch, Dewalt, KPT, Eibenstock, Polymak, etc.)
- Centered grey copyright footer

---

## 🚀 How to Use

1. **Prepare the inventory**:
   - Edit `godown.csv` to include your products (`Item`, `Rate`).

2. **Run the quote system**:
   ```bash
   python cli.py
   ```

3. **Follow the prompts**:
   - Enter company name
   - Enter location or contact
   - Enter credit period
   - Select products and quantities

4. The quote will be saved in `/output` folder as a PDF:
   ```
   output/SKH_<quote-number>.pdf
   ```

---

## 📌 Requirements

- Python 3.7+
- reportlab (install via pip)
  ```bash
  pip install reportlab
  ```

---

## 🔐 Licensing

This software is **licensed, not sold**. You may not reverse engineer, distribute, or share this software without prior permission from the licensor.

See the full **End User License Agreement (EULA)** for details.

---

## 🛡 Legal Notice

- `SalesAutoMate™` is a trademark of **Rajdeep Chatterjee**.
- All generated quotes include **© 2025 SalesAutoMate™. All rights reserved.**
- Any unauthorized use of the name, software, code, or outputs will be subject to legal action.

---

## ✉️ Contact

For licensing, support, or commercial inquiries:

**Rajdeep Chatterjee**  
📧 rc9163253@gmail.com  
📍 Durgapur, West Bengal, India

---

## 🔒 Confidentiality

This software is **proprietary and confidential**. Distribution, duplication, or modification is strictly prohibited outside licensed agreements.
