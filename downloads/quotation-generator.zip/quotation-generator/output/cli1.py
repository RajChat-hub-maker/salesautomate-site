# cli.py
# © 2025 SalesAutoMate™. All rights reserved.
# Licensed under EULA.

import csv
import os
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

GODOWN_FILE = "godown.csv"
OUTPUT_DIR = "output"

def load_products():
    products = []
    with open(GODOWN_FILE, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    return products

def get_quote_id():
    now = datetime.now()
    fiscal = f"{now.year % 100}-{(now.year + 1) % 100}"
    number = now.strftime("%H%M%S")
    return f"SKH/{number}/{fiscal}", number

def generate_pdf(quote_id, customer, company, credit_days, items, total, quote_num):
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    filename = os.path.join(OUTPUT_DIR, f"SKH_{quote_num}.pdf")
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4

    c.setFont("Helvetica", 11)
    c.drawString(50, height - 40, f"To,")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 60, company)
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 80, f"{customer}")
    c.drawString(width - 200, height - 60, f"DATE: {datetime.now().strftime('%d.%m.%Y')}")

    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 110, f"Our Quotation No – {quote_id}")
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 135, "Reference: OVER MAIL")
    c.drawString(50, height - 155, "Dear Sir,")
    c.drawString(50, height - 170, "Thank you very much for the courtesy extended to the undersigned.")
    c.drawString(50, height - 185, "We are pleased to submit below our offer for the following item:")

    y = height - 215
    x_pos = [50, 90, 310, 360, 430]
    headers = ["Sl No.", "Item", "Qty", "Rate", "Amount"]
    c.setFont("Helvetica-Bold", 11)
    for i, h in enumerate(headers):
        c.drawString(x_pos[i], y, h)

    y -= 20
    c.setFont("Helvetica", 10)
    for idx, item in enumerate(items, start=1):
        c.drawString(x_pos[0], y, str(idx))
        c.drawString(x_pos[1], y, item["Item"])
        c.drawString(x_pos[2], y, str(item["Qty"]))
        c.drawRightString(x_pos[3] + 30, y, f"{item['Rate']:.2f}")
        c.drawRightString(x_pos[4] + 30, y, f"{item['Amount']:.2f}")
        y -= 18

    y -= 10
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(x_pos[4] + 30, y, f"Total: ₹{total:.2f}")

    # Terms & Conditions
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "Terms & Condition")
    c.setFont("Helvetica", 10)
    y -= 15
    c.drawString(50, y, "TAX: GST WILL BE ADDED EXTRA AS APPLICABLE.")
    y -= 15
    c.drawString(50, y, f"PAYMENT TERMS: PO AGAINST WITHIN {credit_days} DAYS AS PER MSME.")
    y -= 15
    c.drawString(50, y, "DELIVERY: 5 TO 7 DAYS")
    y -= 15
    c.drawString(50, y, "ALL THE MATERIALS DELIVERY WILL BE SUBJECT TO AVAILABILITY FROM OEM’S END.")
    y -= 20
    c.drawString(50, y, "Please find our offer in line with your requirements and your valued order will reach us at the earliest.")
    y -= 40

    c.drawString(50, y, "Thanks & Regards")
    y -= 15
    c.drawString(50, y, "SHREE KRISHNA HARDWARE")
    y -= 15
    c.drawString(50, y, "MUCHIPARA, DURGAPUR – 12")
    y -= 15
    c.drawString(50, y, "7908526474")
    c.setFont("Helvetica", 7)
    c.drawString(50, 20, "© 2025 SalesAutoMate™. All rights reserved.")

    c.save()
    return filename

def main():
    print("📦 SalesAutoMate™ v2.0 CLI — Quotation Generator\n")
    company = input("Enter company/industry name: ").strip()
    customer = input("Enter industry location or contact person: ").strip()
    credit = input("Enter credit period (in days): ").strip()

    products = load_products()
    selected = []

    print("\n📋 Available Products:")
    for p in products:
        print(f"{p['Item']} — ₹{p['Rate']}")

    while True:
        name = input("\nEnter item name (or 'done'): ").strip()
        if name.lower() == 'done':
            break
        found = next((p for p in products if p["Item"].lower() == name.lower()), None)
        if not found:
            print("❌ Item not found.")
            continue
        try:
            qty = int(input("Enter quantity: ").strip())
        except:
            print("❌ Invalid quantity.")
            continue
        rate = float(found["Rate"])
        selected.append({
            "Item": found["Item"],
            "Qty": qty,
            "Rate": rate,
            "Amount": qty * rate
        })

    if not selected:
        print("❌ No items selected.")
        return

    total = sum(i["Amount"] for i in selected)
    quote_id, quote_num = get_quote_id()
    file = generate_pdf(quote_id, customer, company, credit, selected, total, quote_num)

    print(f"\n✅ Quote generated: {file}")

if __name__ == "__main__":
    main()