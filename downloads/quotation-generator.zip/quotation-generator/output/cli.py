# cli.py
# © 2025 SalesAutoMate™. All rights reserved.
# Licensed under EULA.
# ISO 8601 · ISO/IEC 27001:2022 Compliant

import os
import sys
import hashlib
import subprocess
from datetime import datetime, timedelta
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

LICENSE_PDF = "LICENSE.pdf"
LICENSE_KEY_FILE = "license.key"
OUTPUT_DIR = "output"
LOGO_DIR = "assets/logos"
STATIC_SALT = "SalesAutoMate™_Secure_v2.0"
TRIAL_DAYS = 365

pdfmetrics.registerFont(TTFont("DejaVuSans", "assets/fonts/DejaVuSans.ttf"))

# --- 1. License Agreement ---
def show_license_agreement():
    if not os.path.exists(LICENSE_PDF):
        print(f"❌ License file '{LICENSE_PDF}' not found.")
        sys.exit(1)
    print("\n📜 LICENSE AGREEMENT\n" + "-" * 60)
    result = subprocess.run(["pdftotext", "-layout", LICENSE_PDF, "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print("❌ Error reading license PDF.")
        print(result.stderr.decode())
        sys.exit(1)
    print(result.stdout.decode("utf-8"))
    consent = input("\n☑️ Type 'agree' to accept and continue: ").strip().lower()
    if consent != "agree":
        print("❌ License not accepted. Exiting.")
        sys.exit(0)

# --- 2. License Key Generation & Trial Logic ---
def generate_license_key():
    sys_info = os.uname().sysname + os.uname().nodename
    raw = sys_info + STATIC_SALT
    digest = hashlib.sha256(raw.encode()).hexdigest().upper()
    blocks = [digest[i:i+5] for i in range(0, 25, 5)]
    return "-".join(blocks)

def verify_or_generate_license():
    print("\n🔐 License Key Enforcement\n" + "-" * 40)
    print("Trial version active. This software is valid for 1 year only.")

    expected_key = generate_license_key()

    if os.path.exists(LICENSE_KEY_FILE):
        with open(LICENSE_KEY_FILE, "r") as f:
            lines = f.read().strip().splitlines()
            if len(lines) >= 3 and lines[2].startswith("HASH:"):
                license_key = lines[0].strip()
                start_date = lines[1].strip()
                saved_hash = lines[2][5:].strip()
                verify = f"{license_key}|{start_date}|{expected_key}"
                valid_hash = hashlib.sha256(verify.encode()).hexdigest()
                if saved_hash == valid_hash and license_key == expected_key:
                    dt = datetime.strptime(start_date, "%Y-%m-%d")
                    remaining = (dt + timedelta(days=TRIAL_DAYS)) - datetime.now()
                    if remaining.days >= 0:
                        print(f"✅ License Key Verified. Trial expires in {remaining.days} days.\n")
                        return
                    else:
                        print("❌ Trial expired. Please contact support.")
                        sys.exit(1)
        print("❌ Invalid or corrupted license key.")
        sys.exit(1)

    choice = input("🛠️ No license found. Generate now? (yes/no): ").strip().lower()
    if choice == "yes":
        today = datetime.now().strftime("%Y-%m-%d")
        verify = f"{expected_key}|{today}|{expected_key}"
        key_hash = hashlib.sha256(verify.encode()).hexdigest()
        with open(LICENSE_KEY_FILE, "w") as f:
            f.write(f"{expected_key}\n{today}\nHASH:{key_hash}\n")
        print(f"✅ Trial License Key saved to {LICENSE_KEY_FILE}.\n")
    else:
        print("❌ Operation aborted. License required.")
        sys.exit(1)

# --- 3. Quote ID ---
def get_quote_id():
    now = datetime.now()
    fiscal = f"{now.year % 100}-{(now.year + 1) % 100}"
    number = now.strftime("%H%M%S")
    return f"SKH/{number}/{fiscal}", number

# --- 4. Draw Table ---
def draw_table(c, headers, items, x, y_start):
    row_height = 18
    col_widths = [40, 220, 70, 70, 80]
    y = y_start
    c.setFillColor(colors.lightgrey)
    c.rect(x, y, sum(col_widths), row_height, fill=True, stroke=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 10)
    for i, header in enumerate(headers):
        c.drawString(x + sum(col_widths[:i]) + 2, y + 4, header)
    y -= row_height
    c.setFont("Helvetica", 10)
    for idx, item in enumerate(items, 1):
        row = [
            str(idx),
            item["Item"],
            f"{item['Qty']} {item['Unit']}",
            f"{float(item['Rate']):.2f}",
            f"{float(item['Amount']):.2f}"
        ]
        for i, cell in enumerate(row):
            c.drawString(x + sum(col_widths[:i]) + 2, y + 4, cell)
        c.rect(x, y, sum(col_widths), row_height, stroke=True)
        y -= row_height
    return y

# --- 5. PDF Generator ---
def generate_pdf(quote_id, customer, company, credit_days, items, total, quote_num):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    filename = os.path.join(OUTPUT_DIR, f"SKH_{quote_num}.pdf")
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4

    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(colors.darkred)
    c.drawString(50, height - 40, "SHREE KRISHNA HARDWARE")
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.black)
    c.drawString(50, height - 55, "MUCHIPARA, DURGAPUR – 12   |   7908526474")

    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 110, company)
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 130, customer)
    c.drawRightString(width - 50, height - 110, f"DATE: {datetime.now():%d.%m.%Y}")

    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 160, f"Our Quotation No – {quote_id}")
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 185, "Reference: OVER MAIL")
    c.drawString(50, height - 200, "Dear Sir,")
    c.drawString(50, height - 215, "Thank you very much for the courtesy extended to the undersigned.")
    c.drawString(50, height - 230, "We are pleased to submit below our offer for the following item:")

    y_start = height - 260
    y = draw_table(c, ["Sl No.", "Item", "Quantity", "Rate/Price", "Amount"], items, 50, y_start)
    y -= 10
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(540, y, f"Total: ₹{total:.2f}")

    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "Terms & Condition")
    c.setFont("Helvetica", 10)
    for term in [
        "TAX: GST WILL BE ADDED EXTRA AS APPLICABLE.",
        f"PAYMENT TERMS: PO AGAINST WITHIN {credit_days} DAYS AS PER MSME.",
        "DELIVERY: 5 TO 7 DAYS",
        "ALL THE MATERIALS DELIVERY WILL BE SUBJECT TO AVAILABILITY FROM OEM’S END.",
        "Please find our offer in line with your requirements and your valued order will reach us at the earliest."
    ]:
        y -= 15
        c.drawString(50, y, term)

    y -= 30
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "Office:")
    c.setFont("Helvetica", 10)
    for line in ["MUCHIPARA, G.T ROAD, DURGAPUR – 12", "Mobile: 9434132981 / 93320118604", "Email: skhkhaitan@gmail.com"]:
        y -= 15
        c.drawString(105, y, line)

    y -= 30
    c.drawString(50, y, "Thanks & Regards")
    y -= 15
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "SHREE KRISHNA HARDWARE")

    # Brand Logos Section
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(width / 2, y, "AUTHORIZED SALE & SERVICE:")
    y -= 40
    logos = ["bosch", "dewalt", "eibenstock", "kpt", "dongcheng", "hitachi", "ralliwolf", "fag", "groz", "polymak"]
    logo_size = (70, 30)
    spacing = 20
    total_width = (logo_size[0] + spacing) * 5 - spacing
    x_start = (width - total_width) / 2

    def draw_logo_row(row, y_pos):
        for idx, name in enumerate(row):
            path = os.path.join(LOGO_DIR, f"{name}.png")
            x = x_start + idx * (logo_size[0] + spacing)
            if os.path.exists(path):
                c.drawImage(ImageReader(path), x, y_pos, width=logo_size[0], height=logo_size[1], preserveAspectRatio=True, mask='auto')
            else:
                c.setFillColor(colors.red)
                c.drawString(x, y_pos, f"[{name.upper()}]")

    draw_logo_row(logos[:5], y)
    draw_logo_row(logos[5:], y - 35)

    # Footer
    c.setFont("DejaVuSans", 8)
    c.setFillColor(colors.grey)
    c.drawCentredString(width / 2, 20, "© 2025 ⚙ SalesAutoMate™. All rights reserved.")
    c.save()
    return filename

# --- 6. Main ---
def main():
    show_license_agreement()
    verify_or_generate_license()
    print("\n📦 SalesAutoMate™ v2.0 CLI — Quotation Generator\n")
    company = input("Enter company/industry name: ").strip()
    customer = input("Enter industry location or contact person: ").strip()
    credit = input("Enter credit period (in days): ").strip()
    selected = []

    while True:
        name = input("\nEnter item name (or 'done'): ").strip()
        if name.lower() == 'done': break
        try:
            qty = input("Enter quantity: ").strip()
            unit = input("Enter unit (e.g. pcs, kg, lit): ").strip()
            rate = float(input("Enter rate: ").strip())
            amount = float(qty) * rate
            selected.append({"Item": name, "Qty": qty, "Unit": unit, "Rate": rate, "Amount": amount})
        except:
            print("❌ Invalid entry. Try again.")

    if not selected:
        print("❌ No items selected.")
        return

    total = sum(i["Amount"] for i in selected)
    quote_id, quote_num = get_quote_id()
    file = generate_pdf(quote_id, customer, company, credit, selected, total, quote_num)
    print(f"\n✅ Quote generated: {file}")

if __name__ == "__main__":
    main()

