# cli.py
# © 2025 SalesAutoMate™. All rights reserved.
# Licensed under EULA.

import csv
import os
import sys
import subprocess
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors

GODOWN_FILE = "godown.csv"
LICENSE_PDF = "LICENSE.pdf"
OUTPUT_DIR = "output"

def show_license_and_get_consent():
    if not os.path.exists(LICENSE_PDF):
        print(f"❌ License file '{LICENSE_PDF}' not found.")
        sys.exit(1)

    try:
        print("\n📜 LICENSE AGREEMENT\n" + "-" * 60)
        result = subprocess.run(
            ["pdftotext", "-layout", LICENSE_PDF, "-"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        if result.returncode != 0:
            print("❌ Error reading license PDF.")
            print(result.stderr.decode())
            sys.exit(1)
        print(result.stdout.decode("utf-8"))
    except Exception as e:
        print(f"❌ Failed to load license: {e}")
        sys.exit(1)

    consent = input("☑️  Type 'agree' to accept and continue: ").strip().lower()
    if consent != "agree":
        print("❌ License not accepted. Exiting.")
        sys.exit(0)

def load_products():
    products = []
    with open(GODOWN_FILE, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    return products

def get_quote_id():
    now = datetime.now()
    fiscal = f"{now.year % 100}-{(now.year + 1) % 100}"
    number = now.strftime("%H%M%S")
    return f"SKH/{number}/{fiscal}", number

def draw_table(c, headers, items, x, y_start):
    row_height = 18
    col_widths = [40, 220, 50, 70, 80]
    y = y_start

    c.setFillColor(colors.lightgrey)
    c.rect(x, y, sum(col_widths), row_height, fill=True, stroke=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 10)
    x_pos = x
    for i, header in enumerate(headers):
        c.drawString(x_pos + 2, y + 4, header)
        x_pos += col_widths[i]

    y -= row_height
    c.setFont("Helvetica", 10)

    for idx, item in enumerate(items, start=1):
        x_pos = x
        row_data = [str(idx), item["Item"], str(item["Qty"]), f"{item['Rate']:.2f}", f"{item['Amount']:.2f}"]
        for i, cell in enumerate(row_data):
            c.drawString(x_pos + 2, y + 4, cell)
            x_pos += col_widths[i]
        c.rect(x, y, sum(col_widths), row_height, stroke=True)
        y -= row_height

    return y

def generate_pdf(quote_id, customer, company, credit_days, items, total, quote_num):
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    filename = os.path.join(OUTPUT_DIR, f"SKH_{quote_num}.pdf")
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4

    # Header
    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(colors.darkred)
    c.drawString(50, height - 40, "SHREE KRISHNA HARDWARE")
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.black)
    c.drawString(50, height - 55, "MUCHIPARA, DURGAPUR – 12   |   7908526474")

    # Address
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 90, "To,")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 110, company)
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 130, customer)
    c.drawRightString(width - 50, height - 110, f"DATE: {datetime.now().strftime('%d.%m.%Y')}")

    # Quotation
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 160, f"Our Quotation No – {quote_id}")
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 185, "Reference: OVER MAIL")
    c.drawString(50, height - 200, "Dear Sir,")
    c.drawString(50, height - 215, "Thank you very much for the courtesy extended to the undersigned.")
    c.drawString(50, height - 230, "We are pleased to submit below our offer for the following item:")

    # Table
    y_start = height - 260
    y = draw_table(c, ["Sl No.", "Item", "Qty", "Rate", "Amount"], items, 50, y_start)

    y -= 10
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(540, y, f"Total: ₹{total:.2f}")

    # Terms & Conditions
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "Terms & Condition")
    c.setFont("Helvetica", 10)
    y -= 15
    c.drawString(50, y, "TAX: GST WILL BE ADDED EXTRA AS APPLICABLE.")
    y -= 15
    c.drawString(50, y, f"PAYMENT TERMS: PO AGAINST WITHIN {credit_days} DAYS AS PER MSME.")
    y -= 15
    c.drawString(50, y, "DELIVERY: 5 TO 7 DAYS")
    y -= 15
    c.drawString(50, y, "ALL THE MATERIALS DELIVERY WILL BE SUBJECT TO AVAILABILITY FROM OEM’S END.")
    y -= 20
    c.drawString(50, y, "Please find our offer in line with your requirements and your valued order will reach us at the earliest.")

    # Office
    y -= 30
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "Office:")
    c.setFont("Helvetica", 10)
    c.drawString(105, y, "MUCHIPARA, G.T ROAD, DURGAPUR – 12")
    y -= 15
    c.drawString(105, y, "Mobile: 9434132981 / 93320118604")
    y -= 15
    c.drawString(105, y, "Email: skhkhaitan@gmail.com")

    # Signature
    y -= 30
    c.setFont("Helvetica", 10)
    c.drawString(50, y, "Thanks & Regards")
    y -= 15
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "SHREE KRISHNA HARDWARE")

    # Brands
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(width / 2, y, "AUTHORIZED SALE & SERVICE:")

    y -= 25
    brand_visuals = [
        ("BOSCH", colors.HexColor("#004382"), colors.red),
        ("DEWALT", colors.gold, colors.black),
        ("EIBENSTOCK", colors.black, colors.white),
        ("KPT", colors.HexColor("#FF9933"), colors.white),
        ("DONGCHENG", colors.blue, colors.white),
        ("HITACHI", colors.darkgreen, colors.white),
        ("RALLI WOLF", colors.brown, colors.white),
        ("FAG", colors.HexColor("#993344"), colors.white),
        ("GROZ", colors.black, colors.white),
        ("POLYMAK", colors.HexColor("#B0351F"), colors.white),
    ]

    row1 = brand_visuals[:5]
    row2 = brand_visuals[5:]
    box_width = 100
    spacing = 20
    total_width = (box_width + spacing) * 5 - spacing
    x_start = (width - total_width) / 2

    c.setFont("Helvetica-Bold", 9)
    for idx, (brand, bg, fg) in enumerate(row1):
        x = x_start + idx * (box_width + spacing)
        c.setFillColor(bg)
        c.roundRect(x, y, box_width, 16, 3, fill=True, stroke=False)
        c.setFillColor(fg)
        c.drawCentredString(x + box_width / 2, y + 4, brand)

    y -= 20
    for idx, (brand, bg, fg) in enumerate(row2):
        x = x_start + idx * (box_width + spacing)
        c.setFillColor(bg)
        c.roundRect(x, y, box_width, 16, 3, fill=True, stroke=False)
        c.setFillColor(fg)
        c.drawCentredString(x + box_width / 2, y + 4, brand)

    # Footer
    c.saveState()
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawCentredString(width / 2, 20, "© 2025 SalesAutoMate™. All rights reserved.")
    c.restoreState()
    c.save()
    return filename

def main():
    show_license_and_get_consent()

    print("\n📦 SalesAutoMate™ v2.0 CLI — Quotation Generator\n")
    company = input("Enter company/industry name: ").strip()
    customer = input("Enter industry location or contact person: ").strip()
    credit = input("Enter credit period (in days): ").strip()

    products = load_products()
    items_list = [p['Item'] for p in products]
    selected = []

    print("\n📋 Available Products:")
    for item in items_list:
        print(f"{item}")

    while True:
        name = input("\nEnter item name (or 'done'): ").strip()
        if name.lower() == 'done':
            break
        if name not in items_list:
            print("❌ Item not found.")
            continue
        try:
            qty = int(input("Enter quantity: ").strip())
            rate = float(input("Enter rate: ").strip())
        except:
            print("❌ Invalid quantity or rate.")
            continue
        selected.append({
            "Item": name,
            "Qty": qty,
            "Rate": rate,
            "Amount": qty * rate
        })

    if not selected:
        print("❌ No items selected.")
        return

    total = sum(i["Amount"] for i in selected)
    quote_id, quote_num = get_quote_id()
    file = generate_pdf(quote_id, customer, company, credit, selected, total, quote_num)

    print(f"\n✅ Quote generated: {file}")

if __name__ == "__main__":
    main()