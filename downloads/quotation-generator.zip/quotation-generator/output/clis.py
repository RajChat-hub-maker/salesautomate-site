# cli.py
# © 2025 SalesAutoMate™. All rights reserved.
# Licensed under EULA.

import csv
import os
import sys
import subprocess
import hashlib
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader

GODOWN_FILE = "godown.csv"
LICENSE_PDF = "LICENSE.pdf"
LICENSE_KEY_FILE = "license.key"
OUTPUT_DIR = "output"
LOGO_DIR = "assets/logos"
STATIC_SALT = "SalesAutoMate™_Secure_v2.0"

def show_license_agreement():
    if not os.path.exists(LICENSE_PDF):
        print(f"❌ License file '{LICENSE_PDF}' not found.")
        sys.exit(1)
    print("\n📜 LICENSE AGREEMENT\n" + "-" * 60)
    result = subprocess.run(["pdftotext", "-layout", LICENSE_PDF, "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print("❌ Error reading license PDF.")
        print(result.stderr.decode())
        sys.exit(1)
    print(result.stdout.decode("utf-8"))
    consent = input("\n☑️ Type 'agree' to accept and continue: ").strip().lower()
    if consent != "agree":
        print("❌ License not accepted. Exiting.")
        sys.exit(0)

def generate_license_key():
    system_info = os.uname().sysname + os.uname().nodename
    date_info = datetime.now().strftime("%Y%m%d")
    raw = system_info + STATIC_SALT + date_info
    return hashlib.sha256(raw.encode()).hexdigest()

def verify_or_generate_license():
    print("\n🔒 This software is protected by a License Key.")
    print("Using without a valid license is strictly prohibited.")
    print("Violators may face legal action under software piracy law.\n")

    if os.path.exists(LICENSE_KEY_FILE):
        with open(LICENSE_KEY_FILE, "r") as f:
            key = f.read().strip()
        expected = generate_license_key()
        if key == expected:
            print("✅ License Key verified.")
            return
        else:
            print("❌ Invalid License Key detected!")
            sys.exit(1)

    print("⚠️ No License Key found.")
    choice = input("Would you like to generate one now? (yes/no): ").strip().lower()
    if choice == "yes":
        key = generate_license_key()
        with open(LICENSE_KEY_FILE, "w") as f:
            f.write(key)
        print(f"✅ License Key generated and saved to {LICENSE_KEY_FILE}.")
    else:
        print("❌ Cannot proceed without a License Key.")
        sys.exit(1)

def load_products():
    products = []
    with open(GODOWN_FILE, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    return products

def get_quote_id():
    now = datetime.now()
    fiscal = f"{now.year % 100}-{(now.year + 1) % 100}"
    number = now.strftime("%H%M%S")
    return f"SKH/{number}/{fiscal}", number

def draw_table(c, headers, items, x, y_start):
    row_height = 18
    col_widths = [40, 220, 50, 70, 80]
    y = y_start

    c.setFillColor(colors.lightgrey)
    c.rect(x, y, sum(col_widths), row_height, fill=True, stroke=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 10)
    x_pos = x
    for i, header in enumerate(headers):
        c.drawString(x_pos + 2, y + 4, header)
        x_pos += col_widths[i]

    y -= row_height
    c.setFont("Helvetica", 10)

    for idx, item in enumerate(items, start=1):
        x_pos = x
        row_data = [str(idx), item["Item"], str(item["Qty"]), f"{item['Rate']:.2f}", f"{item['Amount']:.2f}"]
        for i, cell in enumerate(row_data):
            c.drawString(x_pos + 2, y + 4, cell)
            x_pos += col_widths[i]
        c.rect(x, y, sum(col_widths), row_height, stroke=True)
        y -= row_height

    return y

def generate_pdf(quote_id, customer, company, credit_days, items, total, quote_num):
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    filename = os.path.join(OUTPUT_DIR, f"SKH_{quote_num}.pdf")
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4

    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(colors.darkred)
    c.drawString(50, height - 40, "SHREE KRISHNA HARDWARE")
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.black)
    c.drawString(50, height - 55, "MUCHIPARA, DURGAPUR – 12   |   7908526474")

    c.setFont("Helvetica", 11)
    c.drawString(50, height - 90, "To,")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 110, company)
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 130, customer)
    c.drawRightString(width - 50, height - 110, f"DATE: {datetime.now().strftime('%d.%m.%Y')}")

    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 160, f"Our Quotation No – {quote_id}")
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 185, "Reference: OVER MAIL")
    c.drawString(50, height - 200, "Dear Sir,")
    c.drawString(50, height - 215, "Thank you very much for the courtesy extended to the undersigned.")
    c.drawString(50, height - 230, "We are pleased to submit below our offer for the following item:")

    y_start = height - 260
    y = draw_table(c, ["Sl No.", "Item", "Qty", "Rate", "Amount"], items, 50, y_start)

    y -= 10
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(540, y, f"Total: ₹{total:.2f}")

    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "Terms & Condition")
    c.setFont("Helvetica", 10)
    y -= 15
    c.drawString(50, y, "TAX: GST WILL BE ADDED EXTRA AS APPLICABLE.")
    y -= 15
    c.drawString(50, y, f"PAYMENT TERMS: PO AGAINST WITHIN {credit_days} DAYS AS PER MSME.")
    y -= 15
    c.drawString(50, y, "DELIVERY: 5 TO 7 DAYS")
    y -= 15
    c.drawString(50, y, "ALL THE MATERIALS DELIVERY WILL BE SUBJECT TO AVAILABILITY FROM OEM’S END.")
    y -= 20
    c.drawString(50, y, "Please find our offer in line with your requirements and your valued order will reach us at the earliest.")

    y -= 30
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "Office:")
    c.setFont("Helvetica", 10)
    c.drawString(105, y, "MUCHIPARA, G.T ROAD, DURGAPUR – 12")
    y -= 15
    c.drawString(105, y, "Mobile: 9434132981 / 93320118604")
    y -= 15
    c.drawString(105, y, "Email: skhkhaitan@gmail.com")

    y -= 30
    c.setFont("Helvetica", 10)
    c.drawString(50, y, "Thanks & Regards")
    y -= 15
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "SHREE KRISHNA HARDWARE")

    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(width / 2, y, "AUTHORIZED SALE & SERVICE:")
    y -= 40

    logos = ["bosch", "dewalt", "eibenstock", "kpt", "dongcheng", "hitachi", "ralliwolf", "fag", "groz", "polymak"]
    logo_size = (70, 30)
    spacing = 20
    total_width = (logo_size[0] + spacing) * 5 - spacing
    x_start = (width - total_width) / 2
    row1 = logos[:5]
    row2 = logos[5:]

    def draw_logo_row(row, y_pos):
        for idx, name in enumerate(row):
            x = x_start + idx * (logo_size[0] + spacing)
            path = os.path.join(LOGO_DIR, f"{name}.png")
            if os.path.exists(path):
                try:
                    c.drawImage(ImageReader(path), x, y_pos, width=logo_size[0], height=logo_size[1], preserveAspectRatio=True, mask='auto')
                except:
                    c.setFillColor(colors.red)
                    c.drawString(x, y_pos, f"[{name.upper()}]")

    draw_logo_row(row1, y)
    draw_logo_row(row2, y - 35)

    c.saveState()
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawCentredString(width / 2, 20, "© 2025 SalesAutoMate™. All rights reserved.")
    c.restoreState()
    c.save()
    return filename

def main():
    show_license_agreement()
    verify_or_generate_license()
    print("\n📦 SalesAutoMate™ v2.0 CLI — Quotation Generator\n")
    company = input("Enter company/industry name: ").strip()
    customer = input("Enter industry location or contact person: ").strip()
    credit = input("Enter credit period (in days): ").strip()

    products = load_products()
    items_list = [p['Item'] for p in products]
    selected = []

    print("\n📋 Available Products:")
    for item in items_list:
        print(f"{item}")

    while True:
        name = input("\nEnter item name (or 'done'): ").strip()
        if name.lower() == 'done':
            break
        if name not in items_list:
            print("❌ Item not found.")
            continue
        try:
            qty = int(input("Enter quantity: ").strip())
            rate = float(input("Enter rate: ").strip())
        except:
            print("❌ Invalid quantity or rate.")
            continue
        selected.append({
            "Item": name,
            "Qty": qty,
            "Rate": rate,
            "Amount": qty * rate
        })

    if not selected:
        print("❌ No items selected.")
        return

    total = sum(i["Amount"] for i in selected)
    quote_id, quote_num = get_quote_id()
    file = generate_pdf(quote_id, customer, company, credit, selected, total, quote_num)
    print(f"\n✅ Quote generated: {file}")

if __name__ == "__main__":
    main()