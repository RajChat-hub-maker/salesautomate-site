# cli.py
# © 2025 SalesAutoMate™. All rights reserved.
# Licensed under EULA.
# ISO 8601 · ISO/IEC 27001:2022 Compliant

import os
import sys
import hashlib
import subprocess
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.utils import ImageReader

LICENSE_PDF = "LICENSE.pdf"
LICENSE_KEY_FILE = "license.key"
OUTPUT_DIR = "output"
LOGO_DIR = "assets/logos"
STATIC_SALT = "SalesAutoMate™_Secure_v2.0"

# --- 1. License Agreement ---
def show_license_agreement():
    if not os.path.exists(LICENSE_PDF):
        print(f"❌ License file '{LICENSE_PDF}' not found.")
        sys.exit(1)
    print("\n📜 LICENSE AGREEMENT\n" + "-" * 60)
    result = subprocess.run(["pdftotext", "-layout", LICENSE_PDF, "-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print("❌ Error reading license PDF.")
        print(result.stderr.decode())
        sys.exit(1)
    print(result.stdout.decode("utf-8"))
    consent = input("\n☑️ Type 'agree' to accept and continue: ").strip().lower()
    if consent != "agree":
        print("❌ License not accepted. Exiting.")
        sys.exit(0)

# --- 2. License Key ---
def generate_license_key():
    system_info = os.uname().sysname + os.uname().nodename
    date_info = datetime.now().strftime("%Y%m%d")
    raw = system_info + STATIC_SALT + date_info
    digest = hashlib.sha256(raw.encode()).hexdigest().upper()
    blocks = [digest[i:i+5] for i in range(0, 25, 5)]  # Only use first 25 characters
    return "-".join(blocks)

def verify_or_generate_license():
    print("\n🔐 License Key Enforcement\n" + "-" * 40)
    print("This software is strictly protected by a license key.")
    print("Unauthorized use may result in legal action.")
    print("💡 License is bound to system + date.\n")

    expected_key = generate_license_key()

    if os.path.exists(LICENSE_KEY_FILE):
        with open(LICENSE_KEY_FILE, "r") as f:
            key = f.read().strip()
        if key == expected_key:
            print("✅ License Key Verified.\n")
            return
        else:
            print("❌ Invalid License Key. Access denied.")
            sys.exit(1)

    choice = input("🛠️ No license found. Generate now? (yes/no): ").strip().lower()
    if choice == "yes":
        with open(LICENSE_KEY_FILE, "w") as f:
            f.write(expected_key)
        print(f"✅ License Key saved to {LICENSE_KEY_FILE}.\n")
    else:
        print("❌ Operation aborted. License required.")
        sys.exit(1)

# --- 3. Quote ID ---
def get_quote_id():
    now = datetime.now()
    fiscal = f"{now.year % 100}-{(now.year + 1) % 100}"
    number = now.strftime("%H%M%S")
    return f"SKH/{number}/{fiscal}", number

# --- 4. Draw Table ---
def draw_table(c, headers, items, x, y_start):
    row_height = 18
    col_widths = [40, 220, 70, 70, 80]
    y = y_start
    c.setFillColor(colors.lightgrey)
    c.rect(x, y, sum(col_widths), row_height, fill=True, stroke=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 10)
    for i, header in enumerate(headers):
        c.drawString(x + sum(col_widths[:i]) + 2, y + 4, header)
    y -= row_height
    c.setFont("Helvetica", 10)
    for idx, item in enumerate(items, 1):
        row = [
            str(idx),
            item["Item"],
            f"{item['Qty']} {item['Unit']}",
            f"{float(item['Rate']):.2f}",
            f"{float(item['Amount']):.2f}"
        ]
        for i, cell in enumerate(row):
            c.drawString(x + sum(col_widths[:i]) + 2, y + 4, cell)
        c.rect(x, y, sum(col_widths), row_height, stroke=True)
        y -= row_height
    return y

# --- 5. Generate PDF ---
def generate_pdf(quote_id, customer, company, credit_days, items, total, quote_num):
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    filename = os.path.join(OUTPUT_DIR, f"SKH_{quote_num}.pdf")
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4

    # Header
    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(colors.darkred)
    c.drawString(50, height - 40, "SHREE KRISHNA HARDWARE")
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.black)
    c.drawString(50, height - 55, "MUCHIPARA, DURGAPUR – 12   |   7908526474")

    # Customer block
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 110, company)
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 130, customer)
    c.drawRightString(width - 50, height - 110, f"DATE: {datetime.now():%d.%m.%Y}")

    # Quotation info
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 160, f"Our Quotation No – {quote_id}")
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 185, "Reference: OVER MAIL")
    c.drawString(50, height - 200, "Dear Sir,")
    c.drawString(50, height - 215, "Thank you very much for the courtesy extended to the undersigned.")
    c.drawString(50, height - 230, "We are pleased to submit below our offer for the following item:")

    y_start = height - 260
    y = draw_table(c, ["Sl No.", "Item", "Quantity", "Rate/Price", "Amount"], items, 50, y_start)
    y -= 10
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(540, y, f"Total: ₹{total:.2f}")

    # Terms
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "Terms & Condition")
    c.setFont("Helvetica", 10)
    for term in [
        "TAX: GST WILL BE ADDED EXTRA AS APPLICABLE.",
        f"PAYMENT TERMS: PO AGAINST WITHIN {credit_days} DAYS AS PER MSME.",
        "DELIVERY: 5 TO 7 DAYS",
        "ALL THE MATERIALS DELIVERY WILL BE SUBJECT TO AVAILABILITY FROM OEM’S END.",
        "Please find our offer in line with your requirements and your valued order will reach us at the earliest."
    ]:
        y -= 15
        c.drawString(50, y, term)

    # Footer & Contact
    y -= 30
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "Office:")
    c.setFont("Helvetica", 10)
    for line in [
        "MUCHIPARA, G.T ROAD, DURGAPUR – 12",
        "Mobile: 9434132981 / 93320118604",
        "Email: skhkhaitan@gmail.com"
    ]:
        y -= 15
        c.drawString(105, y, line)

    y -= 30
    c.drawString(50, y, "Thanks & Regards")
    y -= 15
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "SHREE KRISHNA HARDWARE")

    # Brand Logos
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawCentredString(width / 2, y, "AUTHORIZED SALE & SERVICE:")
    y -= 40

    logos = {
        "bosch": (80, 35), "dewalt": (70, 30), "eibenstock": (75, 35), "kpt": (85, 38), "dongcheng": (70, 30),
        "hitachi": (70, 30), "ralliwolf": (70, 30), "fag": (70, 30), "groz": (70, 30), "polymak": (70, 30)
    }
    spacing = 20
    total_width = sum(w for w, _ in list(logos.values())[:5]) + spacing * 4
    x_start = (width - total_width) / 2
    logo_names = list(logos.keys())

    def draw_logo_row(names, y_pos):
        x = x_start
        for name in names:
            path = os.path.join(LOGO_DIR, f"{name}.png")
            w, h = logos[name]
            if os.path.exists(path):
                c.drawImage(ImageReader(path), x, y_pos, width=w, height=h, preserveAspectRatio=True, mask='auto')
            else:
                c.setFillColor(colors.red)
                c.drawString(x, y_pos, f"[{name.upper()}]")
            x += w + spacing

    draw_logo_row(logo_names[:5], y)
    draw_logo_row(logo_names[5:], y - 40)

    # Final Footer
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawCentredString(width / 2, 20, "© 2025 ⚙ SalesAutoMate™. All rights reserved.")
    c.save()
    return filename

# --- 6. Main ---
def main():
    show_license_agreement()
    verify_or_generate_license()
    print("\n📦 SalesAutoMate™ v2.0 CLI — Quotation Generator\n")
    company = input("Enter company/industry name: ").strip()
    customer = input("Enter industry location or contact person: ").strip()
    credit = input("Enter credit period (in days): ").strip()
    selected = []

    while True:
        name = input("\nEnter item name (or 'done'): ").strip()
        if name.lower() == 'done': break
        try:
            qty = input("Enter quantity: ").strip()
            unit = input("Enter unit (e.g. pcs, kg, lit): ").strip()
            rate = float(input("Enter rate: ").strip())
            amount = float(qty) * rate
            selected.append({
                "Item": name,
                "Qty": qty,
                "Unit": unit,
                "Rate": rate,
                "Amount": amount
            })
        except:
            print("❌ Invalid entry. Try again.")

    if not selected:
        print("❌ No items selected.")
        return

    total = sum(i["Amount"] for i in selected)
    quote_id, quote_num = get_quote_id()
    file = generate_pdf(quote_id, customer, company, credit, selected, total, quote_num)
    print(f"\n✅ Quote generated: {file}")

if __name__ == "__main__":
    main()

