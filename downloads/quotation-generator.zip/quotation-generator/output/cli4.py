# cli.py
# © 2025 SalesAutoMate™. All rights reserved.
# Licensed under EULA.

import csv
import os
from datetime import datetime
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib import colors

GODOWN_FILE = "godown.csv"
OUTPUT_DIR = "output"

def load_products():
    products = []
    with open(GODOWN_FILE, newline='', encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            products.append(row)
    return products

def get_quote_id():
    now = datetime.now()
    fiscal = f"{now.year % 100}-{(now.year + 1) % 100}"
    number = now.strftime("%H%M%S")
    return f"SKH/{number}/{fiscal}", number

def draw_table(c, headers, items, x, y_start):
    row_height = 18
    col_widths = [40, 220, 50, 70, 80]
    y = y_start

    c.setFillColor(colors.lightgrey)
    c.rect(x, y, sum(col_widths), row_height, fill=True, stroke=True)
    c.setFillColor(colors.black)
    c.setFont("Helvetica-Bold", 10)
    x_pos = x
    for i, header in enumerate(headers):
        c.drawString(x_pos + 2, y + 4, header)
        x_pos += col_widths[i]

    y -= row_height
    c.setFont("Helvetica", 10)

    for idx, item in enumerate(items, start=1):
        x_pos = x
        row_data = [str(idx), item["Item"], str(item["Qty"]), f"{item['Rate']:.2f}", f"{item['Amount']:.2f}"]
        for i, cell in enumerate(row_data):
            c.drawString(x_pos + 2, y + 4, cell)
            x_pos += col_widths[i]
        c.rect(x, y, sum(col_widths), row_height, stroke=True)
        y -= row_height

    return y

def generate_pdf(quote_id, customer, company, credit_days, items, total, quote_num):
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)

    filename = os.path.join(OUTPUT_DIR, f"SKH_{quote_num}.pdf")
    c = canvas.Canvas(filename, pagesize=A4)
    width, height = A4

    # Header Branding
    c.setFont("Helvetica-Bold", 16)
    c.setFillColor(colors.darkred)
    c.drawString(50, height - 40, "SHREE KRISHNA HARDWARE")
    c.setFont("Helvetica", 10)
    c.setFillColor(colors.black)
    c.drawString(50, height - 55, "MUCHIPARA, DURGAPUR – 12   |   7908526474")

    # Address Block
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 90, "To,")
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, height - 110, company)
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 130, customer)
    c.drawRightString(width - 50, height - 110, f"DATE: {datetime.now().strftime('%d.%m.%Y')}")

    # Quotation Block
    c.setFont("Helvetica-Bold", 12)
    c.drawString(50, height - 160, f"Our Quotation No – {quote_id}")
    c.setFont("Helvetica", 11)
    c.drawString(50, height - 185, "Reference: OVER MAIL")
    c.drawString(50, height - 200, "Dear Sir,")
    c.drawString(50, height - 215, "Thank you very much for the courtesy extended to the undersigned.")
    c.drawString(50, height - 230, "We are pleased to submit below our offer for the following item:")

    # Table
    y_start = height - 260
    y = draw_table(c, ["Sl No.", "Item", "Qty", "Rate", "Amount"], items, 50, y_start)

    y -= 10
    c.setFont("Helvetica-Bold", 11)
    c.drawRightString(540, y, f"Total: ₹{total:.2f}")

    # Terms & Conditions
    y -= 40
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "Terms & Condition")
    c.setFont("Helvetica", 10)
    y -= 15
    c.drawString(50, y, "TAX: GST WILL BE ADDED EXTRA AS APPLICABLE.")
    y -= 15
    c.drawString(50, y, f"PAYMENT TERMS: PO AGAINST WITHIN {credit_days} DAYS AS PER MSME.")
    y -= 15
    c.drawString(50, y, "DELIVERY: 5 TO 7 DAYS")
    y -= 15
    c.drawString(50, y, "ALL THE MATERIALS DELIVERY WILL BE SUBJECT TO AVAILABILITY FROM OEM’S END.")
    y -= 20
    c.drawString(50, y, "Please find our offer in line with your requirements and your valued order will reach us at the earliest.")

    # Footer
    y -= 40
    c.setFont("Helvetica", 10)
    c.drawString(50, y, "Thanks & Regards")
    y -= 15
    c.setFont("Helvetica-Bold", 10)
    c.drawString(50, y, "SHREE KRISHNA HARDWARE")
    y -= 15
    c.setFont("Helvetica", 10)
    c.drawString(50, y, "MUCHIPARA, DURGAPUR – 12")
    y -= 15
    c.drawString(50, y, "7908526474")

    # AUTHORIZED BRANDS LOGO STYLE
    y -= 30
    c.setFont("Helvetica-Bold", 11)
    c.drawString(50, y, "AUTHORIZED SALE & SERVICE:")

    y -= 25
    brand_visuals = [
        ("BOSCH", colors.darkblue, colors.red),
        ("DEWALT", colors.gold, colors.black),
        ("EIBENSTOCK", colors.black, colors.white),
        ("KPT", colors.red, colors.white),
        ("DONGCHENG", colors.blue, colors.white),
        ("HITACHI", colors.darkgreen, colors.white),
        ("RALLI WOLF", colors.brown, colors.white),
        ("FAG", colors.purple, colors.white),
        ("GROZ", colors.black, colors.white),
        ("POLYMAK", colors.orangered, colors.white),  # Brick color
    ]

    c.setFont("Helvetica-Bold", 9)
    for brand, bg_color, text_color in brand_visuals:
        c.setFillColor(bg_color)
        c.rect(60, y - 2, 100, 14, fill=True, stroke=False)
        c.setFillColor(text_color)
        c.drawCentredString(110, y + 1, brand)
        y -= 18

    # Footer Watermark
    c.saveState()
    c.setFont("Helvetica", 8)
    c.setFillColor(colors.grey)
    c.drawCentredString(width / 2, 20, "© 2025 SalesAutoMate™. All rights reserved.")
    c.restoreState()

    c.save()
    return filename

def main():
    print("📦 SalesAutoMate™ v2.0 CLI — Quotation Generator\n")
    company = input("Enter company/industry name: ").strip()
    customer = input("Enter industry location or contact person: ").strip()
    credit = input("Enter credit period (in days): ").strip()

    products = load_products()
    selected = []

    print("\n📋 Available Products:")
    for p in products:
        print(f"{p['Item']} — ₹{p['Rate']}")

    while True:
        name = input("\nEnter item name (or 'done'): ").strip()
        if name.lower() == 'done':
            break
        found = next((p for p in products if p["Item"].lower() == name.lower()), None)
        if not found:
            print("❌ Item not found.")
            continue
        try:
            qty = int(input("Enter quantity: ").strip())
        except:
            print("❌ Invalid quantity.")
            continue
        rate = float(found["Rate"])
        selected.append({
            "Item": found["Item"],
            "Qty": qty,
            "Rate": rate,
            "Amount": qty * rate
        })

    if not selected:
        print("❌ No items selected.")
        return

    total = sum(i["Amount"] for i in selected)
    quote_id, quote_num = get_quote_id()
    file = generate_pdf(quote_id, customer, company, credit, selected, total, quote_num)

    print(f"\n✅ Quote generated: {file}")

if __name__ == "__main__":
    main()