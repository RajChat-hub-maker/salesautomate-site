from PIL import Image, ImageDraw, ImageFont

# Increase resolution
img = Image.new("RGB", (800, 800), "white")
draw = ImageDraw.Draw(img)

# Increase font size
font = ImageFont.truetype("SalesAutoMate.ttf", size=600)

# Draw at position (adjust to center)
draw.text((100, 100), "\uE903", font=font, fill="black")

# Save
img.save("logo-highres.png")