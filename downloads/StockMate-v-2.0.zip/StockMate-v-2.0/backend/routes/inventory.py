# === backend/routes/inventory.py ===

import csv
import io
from flask import Blueprint, request, render_template, redirect, session, send_file
from backend.db import get_db_connection
import pandas as pd
from reportlab.pdfgen import canvas

inventory_bp = Blueprint('inventory', __name__)

@inventory_bp.route('/', methods=['GET', 'POST'])
def dashboard():
    conn = get_db_connection()
    search_term = request.form.get('search') if request.method == 'POST' else ""
    if search_term:
        query = """
        SELECT * FROM inventory
        WHERE name LIKE ? OR batch LIKE ?
        """
        like_term = f"%{search_term}%"
        items = conn.execute(query, (like_term, like_term)).fetchall()
    else:
        items = conn.execute('SELECT * FROM inventory').fetchall()
    conn.close()
    return render_template('index.html', items=items, search_term=search_term)

@inventory_bp.route('/add-item', methods=['POST'])
def add_item():
    name = request.form['name']
    qty = int(request.form['quantity'])
    batch = request.form['batch']
    expiry = request.form['expiry']
    conn = get_db_connection()
    conn.execute('INSERT INTO inventory (name, quantity, batch, expiry) VALUES (?, ?, ?, ?)',
                 (name, qty, batch, expiry))
    conn.commit()
    conn.close()
    return redirect('/')

@inventory_bp.route('/update-stock/<int:item_id>/<action>', methods=['POST'])
def update_stock(item_id, action):
    conn = get_db_connection()
    item = conn.execute('SELECT * FROM inventory WHERE id = ?', (item_id,)).fetchone()
    if not item:
        conn.close()
        return "Item not found", 404

    quantity = item['quantity']
    if action == "add":
        quantity += 1
    elif action == "remove" and quantity > 0:
        quantity -= 1

    conn.execute('UPDATE inventory SET quantity = ? WHERE id = ?', (quantity, item_id))
    conn.commit()
    conn.close()
    return redirect('/')

@inventory_bp.route('/export/<format>')
def export_data(format):
    conn = get_db_connection()
    items = conn.execute('SELECT * FROM inventory').fetchall()
    conn.close()

    if format == 'csv':
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(['ID', 'Name', 'Quantity', 'Batch', 'Expiry'])
        for item in items:
            writer.writerow([item['id'], item['name'], item['quantity'], item['batch'], item['expiry']])
        output.seek(0)
        return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv', as_attachment=True, download_name='stockmate.csv')

    elif format == 'excel':
        df = pd.DataFrame(items, columns=items[0].keys())
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Stock')
        output.seek(0)
        return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', as_attachment=True, download_name='stockmate.xlsx')

    elif format == 'pdf':
        buffer = io.BytesIO()
        p = canvas.Canvas(buffer)
        p.setFont("Helvetica", 12)
        y = 800
        p.drawString(50, y, "ID | Name | Quantity | Batch | Expiry")
        y -= 20
        for item in items:
            line = f"{item['id']} | {item['name']} | {item['quantity']} | {item['batch']} | {item['expiry']}"
            p.drawString(50, y, line)
            y -= 20
        p.save()
        buffer.seek(0)
        return send_file(buffer, mimetype='application/pdf', as_attachment=True, download_name='stockmate.pdf')

    return "Unsupported format", 400

