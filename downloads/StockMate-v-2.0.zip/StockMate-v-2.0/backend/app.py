# StockMate Inventory Management System (Flask + SQLite)

import os
from flask import Flask
from backend.routes.auth import auth_bp
from backend.routes.inventory import inventory_bp

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
TEMPLATE_DIR = os.path.join(BASE_DIR, "..", "templates")

app = Flask(__name__, template_folder=TEMPLATE_DIR)
app.secret_key = "your-secret-key"

# Register Blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(inventory_bp)

if __name__ == '__main__':
    app.run(debug=True)

