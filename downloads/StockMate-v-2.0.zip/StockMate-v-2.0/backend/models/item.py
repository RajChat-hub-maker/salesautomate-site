# ===  backend/models/item.py ===

class Item:
    def __init__(self, name, quantity, batch, expiry):
        self.name = name
        self.quantity = quantity
        self.batch = batch
        self.expiry = expiry

